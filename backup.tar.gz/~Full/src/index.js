import mainMenu from './main.js';



mainMenu();