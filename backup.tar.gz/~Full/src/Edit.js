// // Example usage:
// taskEditor.edit(2, {
//   phoneNumber: prompt('Please enter Phone Number: '),
//   taskType: prompt("Please Enter The Task Type: "),
//   deliveryDate: prompt("Please Enter The Delivery Date: "),
//   deliveryTime: prompt("Please Enter The Delivery Hour: "),
//   details: prompt("Please Enter Details if Found: ")
// });




