const fs = require('fs');

const fileName = 'file';

for(let i=1; i<=10; i++) {
  const filePath = `${fileName}${i}.json`;

  if(!fs.existsSync(filePath)) {
    // If the file does not exist, create it and write an empty JSON object to it
    fs.writeFileSync(filePath, '{}');
    console.log(`File ${filePath} has been created.`);
  } else {
    console.log(`File ${filePath} already exists.`);
  }
}