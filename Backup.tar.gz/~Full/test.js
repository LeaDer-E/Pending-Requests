// Timeout function
const timeout = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Run some loop in async function
(async () => {
  // Loop for 5 times
  let i = 0
  while(i < 10) {
    // Do some stuff
    console.log(`Some stuff ${i}`);
    // Wait for timeout 1000 ms
    await timeout(1000);
    i++
  }
})();



console.log('It will be printed 1-st');

async function newStyleDelay() {
    await new Promise(resolve => setTimeout(resolve, 1000))
    console.log('It will be printed 3-rd with delay');
}

newStyleDelay();

console.log('It will be printed 2-nd');
