const fs = require('fs');
const fsfiles = require("node:fs/promises");
const prompt = require("prompt-sync")({ sigint: true });
const timeout = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export const mainMenu = () => {
    console.clear();
    console.log("-------------------------------------------------------");
    console.log("------------------ M A I N - M E N U ------------------");
    console.log("-------------------------------------------------------");
    console.log();
    console.log();
    console.log("==========================");
    console.log("Select What U Whant to Do:");
    console.log("==========================");
    console.log("1) Show ALL Requests.");
    console.log("2) Add Request.");
    console.log("3) Edit Request.");
    console.log("4) Remove Request.");

    const ch =  () => {
        let choice = 0;
        choice = prompt("What's Your Choice!?: ");

        if (choice == 1) {
            showRequests();
            afterShow();
        } else if (choice == 2) {
            addingRequest();
        } else if (choice == 3) {
            editingRequest();
        } else if (choice == 4) {
            deleteRequest();
        } else if (choice !== 1 || choice !== 2 || choice !== 3 || choice !== 4) {
            console.log("=========================================");
            console.log("please pass the right choice, from 1 to 4");
            console.log("=========================================");

            ch()
        }
    }
    ch()
};