const fs = require('fs');
const fsfiles = require("node:fs/promises");
const prompt = require("prompt-sync")({ sigint: true });
const timeout = (ms) => new Promise(resolve => setTimeout(resolve, ms));
import { whenfail } from './fail';
import { showRequests, afterShow } from './show';
import { mainMenu } from './main';

export const editingRequest = () => {

    const whenEdit = () => {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve();
                console.log();
                console.log();
                console.log("Are U Sure to Edit This Task?");
                console.log("===============================");
                console.log("1) Edit");
                console.log("2) Edit Another Task");
                console.log("3) Back TO Main Menu");

                const wrongCh = () => {
                    let choice;
                    choice = prompt("What's Your Choice!?: ");
                
                    if (choice == 1) {
                        edit()
                    } else if (choice == 2) {
                        editingRequest();
                    } else if (choice == 3) {
                        mainMenu();
                    } else if (choice !== 1 || choice !== 2 || choice !== 3) {
                        console.log("=========================================");
                        console.log("please pass the right choice, from 1 to 3");
                        console.log("=========================================");
                        wrongCh()
                    }
                }
                wrongCh()
            },100);

        })
    }

    const edit = () => {
        if (taskID < 10) {
            const write = () => {
                const writeData = async () => {
                    let phone; let type; let lastTime; let description;
                    phone = prompt("Please Enter The Phone Number: ");
                    type = prompt("Please Enter The Type of Request: ");
                    lastTime = prompt("Please Enter The Last Time to Deliver: ");
                    description = prompt("Please Enter The Description if Found: ");
                    let obj = {
                        "ID": `0${taskID}`,
                        "Phone-No.": `${phone}`,
                        "Type": `${type}`,
                        "Delivery-Time": `${lastTime}`,
                        "Description": `${description}`
                        
                    }
                    try {
                        let newFile = await fsfiles.writeFile(
                            `writeFile0${taskID}.json`, JSON.stringify(obj, null,2), "utf-8"
                        );
                    } catch (err) {
                        console.log(`Sorry: ${err}`);
                    }
                };
                writeData();
            }
            write();
        } else if (taskID > 9 && taskID < 100) {
            const write = () => {
                const writeData = async () => {
                    let phone; let type; let lastTime; let description;
                    phone = prompt("Please Enter The Phone Number: ");
                    type = prompt("Please Enter The Type of Request: ");
                    lastTime = prompt("Please Enter The Last Time to Deliver: ");
                    description = prompt("Please Enter The Description if Found: ");
                    let obj = {
                        "ID": `${taskID}`,
                        "Phone No.": `${phone}`,
                        "Type": `${type}`,
                        "Delivery Time": `${lastTime}`,
                        "Description": `${description}`
                    }
                    try {
                        let newFile = await fsfiles.writeFile(
                            `writeFile${taskID}.json`, JSON.stringify(obj, null,2), "utf-8"
                        );
                    } catch (err) {
                        console.log(`Sorry: ${err}`);
                    }
                };
                writeData();
            }
            write();
        } else {
            console.clear();
            console.log("================================================================");
            console.log(`Requests are Full!, Complete Some of Them to add another Request`);
            console.log("================================================================")
            whenfail();
        }
        console.log("=================");
        console.log("=== Edit Done ===");
        console.log("=================");
        setTimeout(mainMenu,500);

    }

    console.clear();
    console.log("-------------------------------------------------------");
    console.log("--------------- E D I T - R E Q U E S T ---------------");
    console.log("-------------------------------------------------------");
    console.log();
    console.log();
    console.log("Enter Task ID To Edit:");
    console.log("======================");
    console.log();
    console.log();
    let taskID;
    taskID = prompt("Please Enter The Task ID: ");
    if (taskID < 10) {
        const read = async () => {
            const readData = async () => {
                fs.readFile(`writeFile0${taskID}.json`, "utf-8", (err, jsonString) => {
                    if (err) {
                        console.log(err);
                    } else {
                        try {
                            const data = JSON.parse(jsonString);
                            console.log(`-------------------------------------------`);
                            console.log(`----------------- ID (${data.ID}) -----------------`);
                            console.log(`-------------------------------------------`);
                            console.log(`Mobile No.-----: ${data["Phone-No."]}`);
                            console.log(`Request Type---: ${data["Type"]}`);
                            console.log(`Until The Hour-: ${data["Delivery-Time"]}`);
                            console.log(`Description----: ${data["Description"]}`);
                            console.log();
                            console.log();
                        } catch (err) {
                            console.log(`============================================`);
                            console.log(`======== E R R O R - I N -> ID (${taskID}) ========`);
                            console.log(`============================================`);
                            console.log(`Error Parsing JSON:`, err);
                            console.log(`============================================`);
                            console.log();
                            console.log();
                        } 
                    }
                });
            };
        readData();
        }
        read();
        
    } else if (taskID > 10 && taskID < 100) {
        const read = async () => {
            const readData = async () => {
                fs.readFile(`writeFile${taskID}.json`, "utf-8", (err, jsonString) => {
                    if (err) {
                        console.log(err);
                    } else {
                        try {
                            const data = JSON.parse(jsonString);
                            console.log(`-------------------------------------------`);
                            console.log(`----------------- ID (${data.ID}) -----------------`);
                            console.log(`-------------------------------------------`);
                            console.log(`Mobile No.-----: ${data["Phone-No."]}`);
                            console.log(`Request Type---: ${data["Type"]}`);
                            console.log(`Until The Hour-: ${data["Delivery-Time"]}`);
                            console.log(`Description----: ${data["Description"]}`);
                            console.log();
                            console.log();
                        } catch (err) {
                            console.log(`============================================`);
                            console.log(`======== E R R O R - I N -> ID (${taskID}) ========`);
                            console.log(`============================================`);
                            console.log(`Error Parsing JSON:`, err);
                            console.log(`============================================`);
                            console.log();
                            console.log();
                        } 
                    }
                });
            };
        readData();
        }  
        read();
    }
    whenEdit();

};