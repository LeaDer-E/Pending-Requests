
import { mainMenu } from './main';





mainMenu();




