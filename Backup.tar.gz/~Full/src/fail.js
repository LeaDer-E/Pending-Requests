const fs = require('fs');
const fsfiles = require("node:fs/promises");
const prompt = require("prompt-sync")({ sigint: true });
const timeout = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export const whenfail = () => {
    console.log()
    console.log()
    console.log("==========================");
    console.log("1) Back to Main Menu.");
    console.log("2) Quit");

    let choiceF;
    choiceF = prompt("What's Your Choice!?: ");

    if (choiceF == 1) {
        mainMenu();
    } else if (choiceF == 2) {
        console.log("");
        console.log("==========================");
        console.log("= Are You Sure To Quit!? =");
        console.log("==========================");
        console.log("1) Back to Main Menu.");
        console.log("2) Quit");

        let choiceFF;
        choiceFF = prompt("What's Your Choice!?: ");
    
        if (choiceFF == 1) {
            mainMenu();
        } else if (choiceFF == 2) {
            process.exit()
        } else {
            console.log("=========================================");
            console.log("please pass the right choice, from 1 to 2");
            console.log("=========================================");
        }
    } else {
        console.log("=========================================");
        console.log("please pass the right choice, from 1 to 2");
        console.log("=========================================");
    }
}