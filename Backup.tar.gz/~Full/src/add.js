export const addingRequest = () => {
    console.log("-------------------------------------------------------");
    console.log("---------------- N E W - R E Q U E S T ----------------");
    console.log("-------------------------------------------------------");
    console.log();
    console.log();
    console.log("Enter Request Values:");
    console.log("=====================");

    fs.readdir(".", (err, files) => {
        let requestNumber = files.length;
        let i = requestNumber;
        while (i <= requestNumber) {
            if (i < 10) {
                const write = () => {
                    const writeData = async () => {
                        let phone; let type; let lastTime; let description;
                        phone = prompt("Please Enter The Phone Number: ");
                        type = prompt("Please Enter The Type of Request: ");
                        lastTime = prompt("Please Enter The Last Time to Deliver: ");
                        description = prompt("Please Enter The Description if Found: ");
                        let obj = {
                            "ID": `0${i}`,
                            "Phone-No.": `${phone}`,
                            "Type": `${type}`,
                            "Delivery-Time": `${lastTime}`,
                            "Description": `${description}`
                            
                        }
                        try {
                            const creating = async () => {
                                if (!fs.existsSync(`writeFile0${i}.json`)) {
                                    // if the file does not exist, create it
                                    fs.writeFileSync(
                                        `writeFile0${i}.json`, JSON.stringify(obj, null,2), "utf-8"
                                    );
                                    console.log();
                                    console.log();
                                    console.log("======================================");
                                    console.log(`==== Task ${i} created successfully. ====`);
                                    console.log("======================================");
                                } else {
                                    console.log();
                                    console.log();
                                    console.log("*********************************");
                                    let e = prompt(`Please Pass an Not Exists ID: `);
                                    if (e <= 9 && !fs.existsSync(`writeFile0${e}.json`) && e.length <= 1) {
                                        fs.writeFileSync(
                                            `writeFile0${e}.json`, JSON.stringify(obj, null,2), "utf-8"
                                        );
                                        console.log();
                                        console.log();
                                        console.log("======================================");
                                        console.log(`==== Task ${e} created successfully. ====`);
                                        console.log("======================================");
                                    } else  if (e >= 10 && e <= 100 && !fs.existsSync(`writeFile0${e}.json`) && e.length <= 2) {
                                        fs.writeFileSync(
                                            `writeFile${e}.json`, JSON.stringify(obj, null,2), "utf-8"
                                        );
                                        console.log();
                                        console.log();
                                        console.log("======================================");
                                        console.log(`==== Task ${e} created successfully. ====`);
                                        console.log("======================================");
                                    } else {
                                        console.log();
                                        console.log();
                                        console.log("==================================================");
                                        console.log("Please Pass Right ID, and make sure it's not Exist");
                                        console.log("==================================================");
                                        creating();
                                    }
                                }
                              }
                              creating();
                        } catch (err) {
                            console.log(`Sorry: ${err}`);
                        }
                    };
                    writeData();
                    i++;
                }
                write();
            } else if (i > 9 && i < 100) {
                const write = () => {
                    const writeData = async () => {
                        let phone; let type; let lastTime; let description;
                        phone = prompt("Please Enter The Phone Number: ");
                        type = prompt("Please Enter The Type of Request: ");
                        lastTime = prompt("Please Enter The Last Time to Deliver: ");
                        description = prompt("Please Enter The Description if Found: ");
                        let obj = {
                            "ID": `${i}`,
                            "Phone No.": `${phone}`,
                            "Type": `${type}`,
                            "Delivery Time": `${lastTime}`,
                            "Description": `${description}`
                        }
                        try {
                            const creating = async () => {
                                if (!fs.existsSync(`writeFile${i}.json`)) {
                                    // if the file does not exist, create it
                                    fs.writeFileSync(
                                        `writeFile${i}.json`, JSON.stringify(obj, null,2), "utf-8"
                                    );
                                    console.log();
                                    console.log();
                                    console.log("======================================");
                                    console.log(`==== Task ${i} created successfully. ====`);
                                    console.log("======================================");
                                } else {
                                    console.log();
                                    console.log();
                                    console.log("*********************************");
                                    let e = prompt(`Please Pass an Not Exists ID: `);
                                    if (e <= 9 && !fs.existsSync(`writeFile0${e}.json`) && e.length <= 1) {
                                        fs.writeFileSync(
                                            `writeFile${e}.json`, JSON.stringify(obj, null,2), "utf-8"
                                        );
                                        console.log();
                                        console.log();
                                        console.log("======================================");
                                        console.log(`==== Task ${e} created successfully. ====`);
                                        console.log("======================================");
                                    } else  if (e >= 10 && e <= 100 && !fs.existsSync(`writeFile${e}.json`) && e.length <= 2) {
                                        fs.writeFileSync(
                                            `writeFile${e}.json`, JSON.stringify(obj, null,2), "utf-8"
                                        );
                                        console.log();
                                        console.log();
                                        console.log("======================================");
                                        console.log(`==== Task ${e} created successfully. ====`);
                                        console.log("======================================");
                                    } else {
                                        console.log();
                                        console.log();
                                        console.log("==================================================");
                                        console.log("Please Pass Right ID, and make sure it's not Exist");
                                        console.log("==================================================");
                                        creating();
                                    }
                                }
                              }
                              creating();
                        } catch (err) {
                            console.log(`Sorry: ${err}`);
                        }
                    };
                    writeData();
                    i++;
                }
                write();
            } else {
                console.clear();
                console.log("================================================================");
                console.log(`Requests are Full!, Complete Some of Them to add another Request`);
                console.log("================================================================")
                whenfail();
            }
        }; 
    });
    afterAdd();
};

export const afterAdd = () => {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve();
            console.log();
            console.log();
            console.log("==========================");
            console.log("1) Add Another Request.");
            console.log("2) Back to Main Menu.");

            const wrongCh = () => {
                let choice;
                choice = prompt("What's Your Choice!?: ");
            
                if (choice == 1) {
                    addingRequest();
                } else if (choice == 2) {
                    mainMenu();
                } else if (choice !== 1 || choice !== 2) {
                    console.log("=========================================");
                    console.log("please pass the right choice, from 1 to 2");
                    console.log("=========================================");
                    wrongCh()
                }
            }
            wrongCh();
        }, 100);
    });
}; 